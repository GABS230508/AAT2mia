const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

function lerJSON(nomeArquivo) {
  return JSON.parse(fs.readFileSync(path.join(__dirname, nomeArquivo + '.json')));
}

function escreverJSON(nomeArquivo, dados) {
  fs.writeFileSync(path.join(__dirname, nomeArquivo + '.json'), JSON.stringify(dados, null, 2));
}

app.get('/', (req, res) => {
  res.send(`
    <h1>Enciclopédia Científica Online</h1>
    <ul> 
      <li><a href="/filtro/pacientes">Filtro de Pacientes</a></li>
      <li><a href="/filtro/medicamentos">Filtro de Medicamentos</a></li>
    </ul>
    <h2>Adicionar:</h2>
    <ul>
      <li><a href="/adicionar/paciente">Adicionar Paciente</a></li>
      <li><a href="/adicionar/medicamento">Adicionar Medicamento</a></li>
    </ul>
  `);
});


app.get('/cadastro', (req, res) => {
  res.send(`
    <h2>Cadastro de Artigos</h2>
    <form action="/cadastro" method="post">
      <label>Título:</label><br>
      <input type="text" name="title"><br>
      <label>Conteúdo:</label><br>
      <textarea name="content"></textarea><br>
      <button type="submit">Enviar</button>
    </form>
  `);
});


app.post('/cadastro', (req, res) => {
  const newArticle = req.body;
  const articles = lerJSON('articles');
  articles.push(newArticle);
  escreverJSON('articles', articles);
  res.redirect('/');
});


app.get('/adicionar/paciente', (req, res) => {
  res.send(`
    <h2>Adicionar Paciente</h2>
    <form action="/adicionar/paciente" method="post">
      <label>Nome do Paciente:</label><br>
      <input type="text" name="nome"><br>
      <label>Idade:</label><br>
      <input type="number" name="idade"><br>
      <button type="submit">Adicionar Paciente</button>
    </form>
  `);
});

app.post('/adicionar/paciente', (req, res) => {
  const newPaciente = req.body;
  const pacientes = lerJSON('pacientes');
  pacientes.push(newPaciente);
  escreverJSON('pacientes', pacientes);
  res.send('Paciente adicionado com sucesso!');
});

app.get('/adicionar/medicamento', (req, res) => {
  res.send(`
    <h2>Adicionar Medicamento</h2>
    <form action="/adicionar/medicamento" method="post">
      <label>Nome do Medicamento:</label><br>
      <input type="text" name="nome"><br>
      <label>Quantidade:</label><br>
      <input type="number" name="quantidade"><br>
      <button type="submit">Adicionar Medicamento</button>
    </form>
  `);
});


app.post('/adicionar/medicamento', (req, res) => {
  const newMedicamento = req.body;
  const medicamentos = lerJSON('medicamentos');
  medicamentos.push(newMedicamento);
  escreverJSON('medicamentos', medicamentos);
  res.send('Medicamento adicionado com sucesso!');
});

app.get('/filtro/pacientes', (req, res) => {
  const pacientes = lerJSON('pacientes');
  res.json(pacientes);
});

app.get('/filtro/medicamentos', (req, res) => {
  const medicamentos = lerJSON('medicamentos');
  res.json(medicamentos);
});


app.get('/visualizacao', (req, res) => {
  const articles = lerJSON('articles');
  res.json(articles);
});

app.listen(PORT, () => {
  console.log(`Servidor iniciado em http://localhost:${PORT}`);
});
